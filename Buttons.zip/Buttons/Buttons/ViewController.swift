//
//  ViewController.swift
//  Buttons
//
//  Created by Ali Hackalife on 11/24/18.
//  Copyright © 2018 Ali Hackalife. All rights reserved.
//

import UIKit
import AVFoundation
import AudioToolbox.AudioServices
import CoreMotion


var motionManager = CMMotionManager()


func toggleTorch(on: Bool) {
    guard let device = AVCaptureDevice.default(for: .video) else { return }
    
    if device.hasTorch {
        do {
            try device.lockForConfiguration()
            
            if on == true {
                device.torchMode = .on
            } else {
                device.torchMode = .off
            }
            
            device.unlockForConfiguration()
        } catch {
            print("Torch could not be used")
        }
    } else {
        print("Torch is not available")
    }
}


class ViewController: UIViewController {
    @IBOutlet weak var lightOutput: UILabel!
    @IBOutlet weak var vibrationOutput: UILabel!
    @IBOutlet weak var shakeOutput: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    override func viewDidAppear(_ animated: Bool) {
        
        
    
        
    motionManager.accelerometerUpdateInterval = 0.8
    motionManager.startAccelerometerUpdates(to: OperationQueue.current!) {(data, error) in
        if let myData = data
        {
            if myData.acceleration.x > 1
            {
                print("something special")
                self.shakeOutput.text = "✓"
            }
            if myData.acceleration.y > 1
            {
                print("something special")
                self.shakeOutput.text = "✓"
            }
            if myData.acceleration.z > 1
            {
                print("something special")
                self.shakeOutput.text = "✓"
            }
        }
        
    }
    
    
    }
   
    @IBAction func schalter(_ sender1: UISwitch) {
        if (sender1.isOn) {
            toggleTorch(on: true)
            print("light on")
            lightOutput.text = "((Light))"
            
        } else {
            toggleTorch(on: false)
            print("light off")
            lightOutput.text = "Light"
        }
    }
    @IBAction func vibrationSwitch(_ sender: UISwitch) {
        if sender.isOn {
        print("((vibration))")
         vibrationOutput.text = "((Vibration))"
            
        } else {
            print("vibration")
            
            vibrationOutput.text = "Vibration"
        }
        
        
    }
    @IBAction func showRed(_ sender: UIButton) {
        
    }
    @IBOutlet weak var neigung: UISlider!
}

